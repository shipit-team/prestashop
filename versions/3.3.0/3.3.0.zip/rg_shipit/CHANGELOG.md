# CHANGELOG
= 3.3.0 =
*Compatibilidad con PrestaShop 9 y PHP 8.5.
*Webhook servido por controlador front (modules/.htaccess de PS 9 bloquea los .php directos).
*Cliente HTTP con cURL nativo (se elimina Guzzle).
*Corregir cache de tarifas: recotiza al cambiar la dirección y evita "Duplicate entry" con peticiones en paralelo.
*Log del módulo unificado y accesible desde el administrador.

= 3.2.0 =
*Aceptar Mercado Pago.

= 3.0.0 =
*Implementar fulfillment para v4.

= 2.4.0 =
*Validar flujo de las tarifas de emergencia cuando no existan datos persistidos.

= 2.3.3 =
*validate address number

= 2.3.2 =
*update process webhook method

= 2.3.1 =
*fix send item dimensions

= 2.3.0 =
*add seller id to orders and shipments

= 2.2.0 =
*change shipit logo

= 2.1.0 =
*adapt plugin to work with prestashop greater than 1770

= 2.0.0 =
*show emergency rates from database
*add endpoint to receive emergency rates
*store emergency rates in dabatabase

= 1.4.2 =
*fix non shipit orders are shipped

= 1.4.1 =
*fix problem with  stranger symbols in address field

= 1.4.0 =
*add insurance to order and shipment
*add composer

= 1.2.3 =
*send orders with shipping type no shipit
*send integration date
*send rate from

= 1.2.2 =
*keep the reference id when creating a new record in the carriers table
*the way to read the seller integrations
*variable initialization

## 1.0.0 -- (2018, Feb 01)
[+] Initial release
