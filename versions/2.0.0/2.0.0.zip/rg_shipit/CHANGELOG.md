# CHANGELOG

= 2.0.0 =
*show emergency rates from database
*add endpoint to receive emergency rates
*store emergency rates in dabatabase

= 1.4.2 =
*fix non shipit orders are shipped

= 1.4.1 =
*fix problem with  stranger symbols in address field

= 1.4.0 =
*add insurance to order and shipment
*add composer

= 1.2.3 =
*send orders with shipping type no shipit
*send integration date
*send rate from

= 1.2.2 =
*keep the reference id when creating a new record in the carriers table
*the way to read the seller integrations
*variable initialization

## 1.0.0 -- (2018, Feb 01)
[+] Initial release
