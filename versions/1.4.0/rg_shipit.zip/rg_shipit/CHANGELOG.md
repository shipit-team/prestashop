# CHANGELOG

= 1.4.0 =
*add bugsnag

= 1.2.3 =
*send orders with shipping type no shipit
*send integration date
*send rate from

= 1.2.2 =
*keep the reference id when creating a new record in the carriers table
*the way to read the seller integrations
*variable initialization

## 1.0.0 -- (2018, Feb 01)
[+] Initial release
